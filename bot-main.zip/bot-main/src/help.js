const help = (prefix) => {
	return `

🇧🇷𝑩𝑶𝑻 𝑭𝑬𝑰𝑻𝑶 𝑷𝑬𝑳𝑶 𝑫𝑨𝑹𝑲𝒁𝑰𝑵🇧🇷

🤖𝑩𝑶𝑻 𝑬𝑺𝑻𝑨 𝑬𝑴 𝑫𝑬𝑺𝑬𝑵𝑽𝑶𝑳𝑽𝑰𝑴𝑬𝑵𝑻𝑶🤖


✌𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺 𝑷𝑨𝑹𝑨 𝑭𝑰𝑮𝑼𝑹𝑰𝑵𝑯𝑨✌

Comandos: *${prefix}sticker* ou *${prefix}stiker*
Desc: converter imagem / gif / vídeo em figurinha
Uso: Eniar ou responder imagem/gif/vídeo com legenda a *${prefix}sticker*\n
Comando : *${prefix}toimg*
Desc: Converte uma figurinha em imagem
Uso: Responda a figurinha com *${prefix}toimg*\n

✌𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺 𝑷𝑨𝑹𝑨 𝑼𝑺𝑨𝑹 𝑬𝑴 𝑮𝑹𝑼𝑷𝑶✌

Comando : *${prefix}welcome [1/0]*
Desc: Ativa o mode de boas vinda para o grupo
Uso: * ${prefix}bemvindo 1 ou 0* \n
Comando : *${prefix}add*
Desc: Adciona membro ao grupo
Uso: *${prefix} add 62813xxxxx* \n
Observação: Só pode ser usado se o bot for administrador do grupo \n
Comando : *${prefix}kick*
Desc: Expulsa membro do grupo
Uso: *${prefix} kick @[membro do grupo]* \n
Observação: Só pode ser usado se o bot for administrador do grupo \n
Comando : *${prefix}promote*
Desc: Torna um membro administrador do grupo
Observação: Só pode ser usado se o bot for administrador do grupo \n
Uso: *${prefix}promote @[numero do membro]* \n
Observação: Só pode ser usado se o bot for administrador do grupo \ n
Comando : *${prefix}demote*
Desc: Retirar cargo de administrador do grupo
Uso: *${prefix}demote @[mumero do membro]* \n
Observação: Só pode ser usado se o bot for administrador do grupo \n
Comando : *${prefix}linkgroup*
Desc: Retorna o link de convite do grupo
Uso: Basta enviar o comando
Comando : *${prefix}leave*
Desc: Use este comando para o bot sair do grupo
Uso: Basta enviar o comando
Nota: Só pode ser usado por administradores do grupo ou o dono no bot\n
Comando : *${prefix}tagall*
Desc: Marca todos os membros do grupo, inclusive administradores
Uso: Basta enviar o comando
Nota: Este comando só pode ser usado se você for administrador do grupo
Comando : *${prefix}tagall2*
Desc: Marca todos os membros do grupo, inclusive administradores
Uso: Basta enviar o comando
Nota: Este comando só pode ser usado se você for administrador do grupo
comando : *${prefix}tagall3*
Desc: Marca todos os membros do grupo, inclusive administradores
Uso: Basta enviar o comando
Nota: Este comando só pode ser usado se você for administrador do grupo

✌𝑷𝑨𝑹𝑨 𝑫𝑶𝑵𝑶 𝑫𝑶 𝑩𝑶𝑻✌

Comando : *${prefix}bc*
Desc: Transmissão
Uso: *${prefix}bc [texto] * \nexemplo: *${prefix}bc sua mensagem*
Nota: Este comando só pode ser usado pelo proprietário do bot \n
Comando : *${prefix}setprefix*
Desc: substituir prefixo
Uso: *${prefix} setprefix [texto | opcional] * \ nexemplo: * $ {prefix}setprefix ?*
Nota: Este comando só pode ser usado pelo proprietário do bot \n\n
`
}

exports.help = help
